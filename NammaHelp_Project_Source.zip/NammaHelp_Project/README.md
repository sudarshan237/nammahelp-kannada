# NammaHelp — Kannada for real life

**Hackathon:** Kannada Digital Innovation Hackathon 2026  
**Selected problem statement:** Kannada in Everyday Life (Problem Statement 03)  
**Type:** Static, client-side MVP

NammaHelp helps non-Kannada speakers find practical Kannada phrases for everyday situations in Karnataka. It focuses on situation-first phrase discovery rather than a long language course.

## Features
- Browse six contexts: transport, shopping, food, healthcare, education, and workplace.
- Search by English phrase, Kannada text, transliteration, category, or context.
- See Kannada script, Latin transliteration, and a short context note.
- Save phrases using `localStorage` on the current browser/device.
- Complete a small multiple-choice practice quiz.
- Copy phrases for quick use.
- Responsive layout for mobile and desktop; no account or API key required.

## Run locally
Open `index.html` in a modern browser. The app is static and has no build step or backend dependency.

## Deploy
This is a static HTML site. Upload the project folder to a static host such as Vercel, Netlify, or GitHub Pages. For Vercel/Netlify, use the project root as the publish directory; no build command is needed.

## Important scope and limitations
- The phrasebook is curated sample content. Wording, transliteration, and regional usage can vary; verify important phrases with a fluent Kannada speaker.
- This MVP does not provide live AI translation, speech recognition, audio playback, or automated pronunciation scoring.
- Saved phrases remain in browser local storage and are not synchronised between devices.
- It is not a substitute for professional medical or emergency assistance.

## Project description for submission
NammaHelp is a mobile-friendly web app that helps non-Kannada speakers find practical Kannada phrases for transportation, shopping, food, healthcare, education, and workplaces. It pairs curated Kannada phrases with Latin transliteration and usage context, and includes search, local bookmarks, and a short practice quiz so users can prepare for real interactions in Karnataka.
